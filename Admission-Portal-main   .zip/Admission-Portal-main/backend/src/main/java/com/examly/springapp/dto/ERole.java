package com.examly.springapp.dto;

public enum ERole {
    USER,
	ADMIN
}
